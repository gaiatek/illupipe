# No need to use this function with BeadStudio v2 or higher
parseCSVData = function(dframe,typ,colPatt=""){

  if (typ=="qcinfo") idCol <- "ArrayID"
  if (typ=="data")   idCol <- "TargetID"
  
  if (dim(dframe)[2] == 1){
    if (typ=="qcinfo")   {
      colPatt <- "AVG"
      nshort  <- nrow(dframe)
    }
    
    if (typ=="data") {
      if (colPatt=="") stop("You must provide arrayId")
      nshort <- 2000 # the columns name will found before the 2000th entry. No need to look at all data.
    }
    if (length(grep(dframe[1:nshort,],pattern=colPatt,perl=T))==0){
      stop("Wrong arrayID")
    }
    
    nbCol         <- length(grep(dframe[1:nshort,],pattern=colPatt,perl=T)) + 1  # Number of columns (+1 for the ID column not found by the pattern)
    idColIndex    <- grep(dframe[1:nshort,], pattern=idCol,perl=T)               # Index of TargetID or ArrayID column
    columnNames   <- dframe[grep(dframe[1:nshort,],pattern=colPatt,perl=T),]     # Actual column names containing pattern
    columnNames   <- as.character(columnNames)
    columnNames   <- c(idCol,columnNames)                                        # Adding id column in column names
    data2         <- dframe[(idColIndex+nbCol):nrow(dframe),]  # Extract the data part
    data3         <- matrix(data2,ncol=nbCol,byrow=T)          # Format in matrix
    # if data, we only want the Avg signal columns.
  }
  if (dim(dframe)[2] > 1){
      data3 <- dframe[(which(dframe==idCol)+1):dim(dframe)[1],]
      columnNames <- dframe[which(dframe==idCol),]
              
  }
  if(mode(columnNames)=="list")  columnNames <- as.character(unlist(columnNames))
    colnames(data3) <- as.character(columnNames)
  
  if (typ=="data"){
      data3 <- data3[,c(grep(colnames(data3),pattern="TargetID",perl=T),grep(colnames(data3),pattern="AVG_Signal",perl=T))]
  } 
  return(data3)
}
#-------------------------------------------------------------------------------
#  Generates the array summary without generating the complete report
getSummaryArray <- function(dataArray,qcArray){

  dataArray    <- checkMicroarrayData(dataArray)
  summaryArray <- getSummary(dataArray,"colnames")   # get array summary
  bkgs         <- qcArray[,grep("signal[-._]negative",colnames(qcArray),perl=T,ignore.case=T)]

  if(dim(bkgs)[2]==0){
    bkgs <- qcArray[,grep("negative", colnames(qcArray),perl=T,ignore.case=T)]
  }

  calls        <- getNbOverCutoff(dataArray,bkgs) # bkgs is a vector of background
  summaryArray <- cbind(summaryArray,calls)
  return(summaryArray)
}
# -------------------------Function---------------------------------------
# This function makes the barplot of the qcinfo data associated with the array
# column names = sampleId
plotQcInfo <- function(qcArray,qcPool) {
  

  nbSamples  <- nrow(qcArray)
  colnames(qcArray) <- gsub(pattern="[_-]",".",colnames(qcArray),perl=T)
  colnames(qcPool)  <- gsub(pattern="[_-]",".",colnames(qcPool),perl=T)
  
  colnamPatt <- c("biotin|gene|high.stringency.hyb|housekeeping|negative|cy3.hyb|labeling|low.stringency.hyb")
    
  qcArray <- qcArray[,grep(colnamPatt, colnames(qcArray),perl=T,ignore.case=T)]
  qcPool  <- qcPool[,grep(colnamPatt, colnames(qcPool),perl=T,ignore.case=T)]
  
  if (dim(qcArray)[2]!=dim(qcPool)[2]) stop("PQI1_Pool and array don't have the same number of controls")
  if (all(colnames(qcArray)%in%colnames(qcPool))==F) stop("PQI1_Pool and array don't have the same controls")

  qcArray <- checkMicroarrayData(qcArray)
  qcPool  <- checkMicroarrayData(qcPool)
 
  qcPoolMean     <- apply(qcPool,2,mean)
  qcPoolMeanLog2 <- log(qcPoolMean,2)
  
  qcAllLog2  <- rbind(log(qcArray,2),qcPoolMeanLog2)
  color      <- rainbow(nrow(qcArray)+1)
  
  #Error bars
  errorUp     <-  qcPoolMean + apply(qcPool,2,sd)
  errorUpLog2 <- log(errorUp,2)
  
  colnames(qcAllLog2) <- gsub("AVG.Signal.","",colnames(qcAllLog2),perl=T,ignore.case=T)
  colnames(qcAllLog2) <- gsub("AVG.SeqVAR.negative", "noise",colnames(qcAllLog2),perl=T,ignore.case=T)
  colnames(qcAllLog2) <- gsub(".hyb", "",colnames(qcAllLog2),perl=T,ignore.case=T)
  
  sm1 <- barplot(as.matrix(qcAllLog2),beside=T, names.arg=colnames(qcAllLog2),
         ylab="log2",col=color,xpd=F,ylim=c(0,16))
  legend(x= "topright",legend= c(rownames(qcArray),"pool"),cex=0.9,fill=color,inset=0.02,bty="n")

  #vertical segment of error bar
  segments(
  x0 <- sm1[(nrow(qcArray)+1),],
  y0 <- as.numeric(qcAllLog2[(nrow(qcArray)+1),]),
  x1 <- sm1[(nrow(qcArray)+1),],
  y1 <- as.numeric(errorUpLog2))
  # horizontal segment of error bar
  segments(
  x0 <- sm1[(nrow(qcArray)+1),]-0.1,
  y0 <- as.numeric(errorUpLog2),
  x1 <- sm1[(nrow(qcArray)+1),]+0.1,
  y1 <- as.numeric(errorUpLog2))
}
#-------------------------------------------------------------------------------
plotQcinfo2 <- function(qcArray, qcPool, arrayId, typ="lines"){

    nbSamples  <- nrow(qcArray)
    colnames(qcArray) <- gsub(pattern="[_-]",".",colnames(qcArray),perl=T)
    colnames(qcPool)  <- gsub(pattern="[_-]",".",colnames(qcPool),perl=T)

    colnamPatt   <- c("biotin|gene|high.stringency.hyb|housekeeping|negative|cy3.hyb|labeling|low.stringency.hyb")
    qcArray <- qcArray[,grep(colnamPatt, colnames(qcArray),perl=T)]
    qcPool  <- qcPool[,grep(colnamPatt, colnames(qcPool),perl=T)]

    qcArray <- checkMicroarrayData(qcArray)
    qcPool  <- checkMicroarrayData(qcPool)

    qcPoolMean <- apply(qcPool,2,mean)

    dat <- t(rbind(qcArray,pool_pool = qcPoolMean))

    graphNames <- rownames(dat)
    xLabel     <- unlist(strsplit(colnames(dat),split="_"))[seq(2,2*ncol(dat),2)]

    #nplot = nrow(dat)
    #nr = 2
    #nc = 4
    #seqbeg = nplot+1

    #seqend = nr*nc-nplot  # number of unutilized plotting spaces
    #mylayout =  layout(matrix(c(seq(1,nplot),rep(seqbeg,seqend)),
    #            nrow = nr, ncol= nc, byrow=T))


    #layout.show(mylayout)

    #par(omi=c(0.25,0.05,0.3,0.05))
    #par(mar = rep(1.75,4))

    for (p in 1:length(graphNames)){

      maxy <- max(dat[graphNames[p],])
      miny <- min(dat[graphNames[p],])

      # blank  -- setting the axis limit
      plot(x=c(0.0001),xlim =c(1,length(xLabel)),xaxt="n",ylim=c(miny,maxy),pch=".",col="white",ylab="")

      # x axis
      axis(1, at=seq(1,length(xLabel)),labels=xLabel, cex.axis = 0.6, las=3)
      title(as.character(graphNames[p]),cex.main=0.95)

      v <- dat[graphNames[p],]
      if (typ=="lines")  lines(v, col="red",lwd=2,cex.axis=0.65)
      if (typ=="points") points(v, col="red",pch=19)
      points(9,dat[graphNames[p],9],col="blue",pch=8)
  }
}
#-------------------------------------------------------------------------------
#--------End function---------------------------------------------------------------


#---Function------------------reportOnArray---------------------------------------
# Main function to create the reporting plot
# data.array   : data to report on 
# data.pool    : pool of samples
# summ.pool    : pool of metrics(min, max, 1st qu., median, mean, 3rd qu) for each sample
# qcinfo.array : quality control information about the data we are reporting on
# qcinfo.pool  : pool of qc info
# metaData     : data describing the chip we are reporting on
# nbSamples     : number of samples
# dev          : graphical device, if null the graph will be output in the x11 console
# pQCType      : type of graph for the qc control : 1: barplot 2: lines or points
# returns a reportObject

reportOnArray <- function(dataArray, dataPool,
                         qcArray, qcPool,
                         summaryPool, metaData, sampleNames,
                         dev=NULL, pQcType=1){
  
  #--------------------Settings--------------------------------
 
  deviceOff  <- 0
  reportInfo <- NULL
  arrayId    <- colnames(dataArray)
  sampleId   <- as.vector(sampleNames[,"SampleName"])
  nbSamples  <- nrow(sampleNames)
  
  #------------------Data combinaison, summary and comparison----------------
  
  dataArray    <- checkMicroarrayData(dataArray)
  dataPool     <- checkMicroarrayData(dataPool)
  summaryPool  <- checkMicroarrayData(summaryPool)
  summaryArray <- getSummary(dataArray,"colnames")   # get array summary

  bkgs <- qcArray[,grep("negative",colnames(qcArray),perl=T,ignore.case=T)]
                            
  calls <- getNbOverCutoff(dataArray,bkgs) # bkgs is a vector of background
  summaryArray <- cbind(summaryArray,calls)
  
  poolMean <- computeStatistic(dataPool,"row","mean") # get mean of pool
  poolMadSummary  <- computeStatistic(summaryPool,"col","mad")  # get mad of pool sample summaries
  poolMeanSummary <- computeStatistic(summaryPool,"col","mean")
  
  flag  <- flagOutlier(summaryArray, as.vector(poolMeanSummary), as.vector(3*t(poolMadSummary)))
  #---------------------------Arrange data for display-------------------------- 

  poolInfo <- rbind(t(poolMeanSummary),3*t(poolMadSummary))
  poolInfo <- zapsmall(poolInfo, digits=6)
  #  Round calls column
  poolInfo[,grep(".*[cC]alls",colnames(poolInfo),perl=T)] <- round(poolInfo[,grep(".*[cC]alls",colnames(poolInfo),perl=T)])
  rownames(poolInfo) <- c("Pool mean","3*MAD")
  
  summaryAll  <- rbind(summaryArray, poolInfo)
  columnNames <- colnames(summaryAll)
  summaryAll  <- cbind(c(sampleId,"-","-"),summaryAll,c(rep("|__|",length(sampleId)),"  -  ","  -  "))
  # Rename columns
  colnames(summaryAll) <- c("Sample ID :",columnNames[1:(length(columnNames)-1)],"Calls :", "Fail :")
  
  #-------------------------Get color matrix for summary display----------------
  colorMx <- ifelse(flag==1,"red","black")
  colorMx <- cbind(rep("black",nrow(flag)),colorMx,rep("black",nrow(flag)))     # adding tow black columns for sample Id and Pass/Fail
  colorMx <- rbind(colorMx, rep("black",ncol(colorMx)),rep("black",ncol(colorMx))) #adding two rows for pool mean and 3MAD
  


  #---------------------------Graphical---------------------------------------
  if (!(is.null(dev))) {
    idarray  <- strsplit(arrayId,"_")[[1]][1]
    filename <- paste(idarray,substr(date(),5,7),substr(date(),9,10))
    if(dev == "ps")     {
       postscript(file=paste(filename,"_",pQcType,".ps",sep=""))
       deviceOff  <- 1
    }
    if(dev == "pdf")  {
       pdf(file=paste(filename,"_",pQcType,".pdf",sep=""),width=10.5,height=8)
       deviceOff  <- 1
    }
  }
  else x11(width = 11,height = 8)
 
  par(omi=c(0.05,0.05,0.2,0.05))
  if(pQcType==1) {
     mylayout <- layout(matrix(c(1,1,1,2,3,3,3,3,4,4,4,5,6,6,6,6,7,7,7,8),
            ncol    = 4,byrow=T),
            widths  = c(1/4,1/4,1/4,1/4),
            heights = c(1/9,lcm(0.75),4/9,lcm(0.75),4/9))
  }
  if(pQcType==2) {
     mylayout <- layout(matrix(c(1,1,1,1,2,3,3,3,3,3,4,5,6,7,12,8,9,10,11,12,13,13,13,13,13,14,14,14,14,15),
            ncol    = 5,byrow=T),
            widths  = c(1/6,1/6,1/6,1/6,2/6),
            heights = c(1.5/13,lcm(0.75),3/13,3/13,lcm(0.75),5/13))
  
  }
  #layout.show(mylayout)
 
  titleCex <- 1.3
  if (nbSamples>7) {
    plotCex  <- 0.95
  }
  if (nbSamples<7) {
    plotCex  <- 0.98
  }
  # Metadata section
  par(mar = c(0.1, 0.05, 0.05, 0.05))
  textplot2(metaData, show.rownames=F,show.colnames=T,mar=c(0,0,0,0),halign="left",cmar=2,cex=0.95)

  mtext(paste("NIML MICROARRAY ANALYSIS  Report generated on",format(Sys.time(), "%d-%b-%Y"),sep=" "),cex = 0.8, font=4,adj=0,col="blue",outer=T)
  
  # Pass/ failed section 
  passFailText <- rbind(c("Pass : |______/______|        "),
                        c("Name : _______________________"),
                        c("Date : _______________________"))
  

  par(mar = c(0.01, 0.1, 0.1, 1.0))
  textplot2(passFailText,show.colnames=F,show.rownames=F,bty="c",mar=c(0,0,0,0),cex=0.98,rmar=1.12,halign="left")
  box(col="black")
  
  # QC info and control section
  par(mar = c(0.01, 0.1, 1.0, 0.1))
  writeSectionTitle("QC information", cex=titleCex)
  
  par(mar = c(1.2, 3.7, 1.2, 0.9))
  if(pQcType ==1) plotQcInfo(qcArray, qcPool)
  if(pQcType ==2) plotQcinfo2(qcArray, qcPool)
  
  par(mar = c(0.8, 0.8, 1.2, 1))
  textplot2(" ",show.rownames=F,show.colnames=F)
  if(pQcType ==2)textplot2(" ",show.rownames=F,show.colnames=F)
 
  #   Sample section
  par(mar = c(0.01, 0.1, 1.0, 0.1))
  writeSectionTitle("Samples",cex=titleCex) 
  
  par(mar = c(0, 0.01, 0.1, 0.1))
  textplot2(summaryAll,mar=c(0,0,0,0),halign="left",cmar=1.0,cex=plotCex,colorMx=colorMx)
 
  par(mar = c(1.2, 0.8, 1.2, 1))

  dataAll <- merge(dataArray,poolMean,by ="row.names",all=F)

  colnames(dataAll)[length(dataAll)] <- "pool"
  rownames(dataAll)<- dataAll[,1]
  dataAll          <- dataAll[,-(1)]

  print(colnames(dataAll))
  plotDensitiesMat(dataAll)
  
  if (deviceOff==1) dev.off()
  #----------------------end graphical----------------------------------------

  reportInfo$sampleId   <- sampleId
  reportInfo$summaryAll <- summaryAll
  return(reportInfo)
}
#-------------------------------end reportOnArray------------------------------
