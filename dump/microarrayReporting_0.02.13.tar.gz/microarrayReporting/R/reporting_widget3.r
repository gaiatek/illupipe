
#---------------------------------------------------------------------------------
dataFileWidget<- function(){
  library(widgetTools)
  library(tkWidgets)
  PWEnv <- new.env(hash = T, parent = parent.frame(1))

  dataLabel   <- label(wName = "dataLabel",wValue="Data File Name: ", wEnv=PWEnv)
  dataEntry   <- entryBox(wName = "dataEntry", wValue = "", wEnv = PWEnv)

  qcLabel     <- label(wName = "qcLabel",wValue="QC File Name: ", wEnv=PWEnv)
  qcEntry     <- entryBox(wName = "qcEntry", wValue = "", wEnv = PWEnv)

  sampleLabel <- label(wName = "sampleLabel",wValue="Sample File Name (optional): ", wEnv=PWEnv)
  sampleEntry <- entryBox(wName = "sampleEntry", wValue = "", wEnv = PWEnv)

  dataBrowse <- function() {
    #tempValue    <- fileBrowser(textToShow = "Choose Data File", nSelect=1)
    tempValue    <-  tclvalue(tkgetOpenFile())
    temp         <- get(wName(dataEntry), env = PWEnv)
    wValue(temp) <- paste(tempValue, sep = "", collapse = ";")
    assign(wName(dataEntry), temp, env = PWEnv)
  }
  qcBrowse <- function() {
    #tempValue    <- fileBrowser(textToShow = "Choose QC File", nSelect=1)
    tempValue    <-  tclvalue(tkgetOpenFile())
    temp         <- get(wName(qcEntry), env = PWEnv)
    wValue(temp) <- paste(tempValue, sep = "", collapse = ";")
    assign(wName(qcEntry), temp, env = PWEnv)
  }
  sampleBrowse <- function() {
    #tempValue    <- fileBrowser(textToShow = "Choose Sample File",nSelect=1)
    tempValue    <-  tclvalue(tkgetOpenFile())
    temp         <- get(wName(sampleEntry), env = PWEnv)
    wValue(temp) <- paste(tempValue, sep = "", collapse = ";")
    assign(wName(sampleEntry), temp, env = PWEnv)
  }

  dataButton   <- button(wName = "dataButton",   wValue = "Browse", wFuns = list(command = dataBrowse),  wEnv = PWEnv)
  qcButton     <- button(wName = "qcButton",     wValue = "Browse", wFuns = list(command = qcBrowse),    wEnv = PWEnv)
  sampleButton <- button(wName = "sampleButton", wValue = "Browse", wFuns = list(command = sampleBrowse),wEnv = PWEnv)
  
  pWidgets <- list(dataRow   = list(dataLabel = dataLabel, dataEntry = dataEntry, dataButton  = dataButton ),
                   qcRow     = list(qcLabel = qcLabel, qcEntry = qcEntry, qcButton = qcButton),
                   sampleRow = list(sampleLabel = sampleLabel, sampleEntry = sampleEntry, sampleButton = sampleButton))

  aWidget <- widget(wTitle = "Microarray Reporting", pWidgets, preFun=function(){}, postFun=function(){},funs = list(), env = PWEnv,defaultNames=c("OK","Cancel"))


  return(list(datafile   = wValue(pWidgets(aWidget)[["dataRow"]][["dataEntry"]]),
              qcfile     = wValue(pWidgets(aWidget)[["qcRow"]][["qcEntry"]]),
              samplefile = wValue(pWidgets(aWidget)[["sampleRow"]][["sampleEntry"]])))
}
#------------------------------------------------------------------------------------------------------------------------
poolFileWidget<-function(){
  PWEnv3 <- new.env(hash = T, parent = parent.frame(1))

  pDataLabel <- label(wName = "pDataLabel",wValue="Pooled Data File : ", wEnv = PWEnv3)
  pDataEntry <- entryBox(wName = "pDataEntry", wValue = "", wEnv = PWEnv3)

  pQcLabel   <- label(wName = "pQcLabel",wValue="Pooled QC File : ", wEnv = PWEnv3)
  pQcEntry   <- entryBox(wName = "pQcEntry", wValue = "", wEnv = PWEnv3)

  pSummaryLabel <- label(wName = "pSummaryLabel",wValue="Pool Summary File: ", wEnv=PWEnv3)
  pSummaryEntry <- entryBox(wName = "pSummaryEntry", wValue = "", wEnv = PWEnv3)

  bPoolTypeLabel <- label(wName = "Pool type", wValue = "Select one:  ", wEnv = PWEnv3)
  bPoolTypeRadio <- radioButton(wName = "poolType", wValue = c(HUMAN_REFSEQ8_V2 = TRUE,
                       HUMAN_REFSEQ8_V1 = FALSE, MOUSE_REFSEQ8_V1 = FALSE, HUMAN_WG6_V1 = FALSE, HUMAN_WG6_V2=FALSE), wEnv = PWEnv3)

  pDataBrowse <- function() {
    #tempValue    <- fileBrowser(textToShow = "Choose Pooled Data File", nSelect=1)
    tempValue    <- tclvalue(tkgetOpenFile())
    temp         <- get(wName(pDataEntry), env = PWEnv3)
    wValue(temp) <- paste(tempValue, sep = "", collapse = ";")
    assign(wName(pDataEntry), temp, env = PWEnv3)
  }
  pQcBrowse <- function() {
    #tempValue    <- fileBrowser(textToShow = "Choose Pooled QC File", nSelect=1)
    tempValue    <-  tclvalue(tkgetOpenFile())
    temp         <- get(wName(pQcEntry), env = PWEnv3)
    wValue(temp) <- paste(tempValue, sep = "", collapse = ";")
    assign(wName(pQcEntry), temp, env = PWEnv3)
  }
  pSummaryBrowse <- function() {
    #tempValue    <- fileBrowser(textToShow = "Choose Pooled Summary File",nSelect =1)
    tempValue    <-  tclvalue(tkgetOpenFile())
    temp         <- get(wName(pSummaryEntry), env = PWEnv3)
    wValue(temp) <- paste(tempValue, sep = "", collapse = ";")
    assign(wName(pSummaryEntry), temp, env = PWEnv3)
  }

  pDataButton    <- button(wName = "pDataButton", wValue = "Browse", wFuns = list(command = pDataBrowse),wEnv = PWEnv3)
  pQcButton      <- button(wName = "pQcButton", wValue = "Browse", wFuns = list(command = pQcBrowse),wEnv = PWEnv3)
  pSummaryButton <- button(wName = "pSummaryButton", wValue = "Browse", wFuns = list(command = pSummaryBrowse),wEnv = PWEnv3)

  pWidgets <- list(pDataRow    = list(pDataLabel = pDataLabel, pDataEntry = pDataEntry, pDataButton  = pDataButton ),
                   pQcRow      = list(pQcLabel = pQcLabel, pQcEntry = pQcEntry, pQcButton = pQcButton),
                   pSummaryRow = list(pSummaryLabel = pSummaryLabel, pSummaryEntry = pSummaryEntry, pSummaryButton = pSummaryButton),
                   pPoolType   = list(bPoolTypeLabel = bPoolTypeLabel, bPoolTypeRadio = bPoolTypeRadio))

  aWidget <- widget(wTitle = "Microarray Reporting (pool)", pWidgets, preFun=function(){}, postFun=function(){},funs = list(), env = PWEnv3,defaultNames=c("OK","Cancel"))
  return(list(pDataFile    = wValue(pWidgets(aWidget)[["pDataRow"]][["pDataEntry"]]),
              pQcFile      = wValue(pWidgets(aWidget)[["pQcRow"]][["pQcEntry"]]),
              pSummaryFile = wValue(pWidgets(aWidget)[["pSummaryRow"]][["pSummaryEntry"]]),
              pPoolType    = wValue(pWidgets(aWidget)[["pPoolType"]][["bPoolTypeRadio"]])))
}
#-------------------------------------------------------------------------------------------------------------------
metaWidget<-function(arrayIds){
  PWEnv2    <- new.env(hash = T, parent = parent.frame(1))
  pWidgets2 <- list()

  # header
  indexLabel0    <- label(wName = "indexLabel0",wValue="Index", wEnv=PWEnv2,wWidth=5)
  arrayIdLabel0  <- label(wName = "arrayIdLabel0",wValue="ArrayIds", wEnv=PWEnv2,wWidth=10)
  projectEntry0  <- entryBox(wName = "projectEntry0", wValue = "ProjectName", wEnv = PWEnv2,wWidth=20)
  datasetEntry0  <- entryBox(wName = "datasetEntry0", wValue = "DatasetName", wEnv = PWEnv2,wWidth=20)
  dateEntry0     <- entryBox(wName = "dateEntry0", wValue = "ProjectDate",wEnv = PWEnv2,wWidth=15)

  pWidgets2 <- list("header"=list(indexLabel0 = indexLabel0, arrayIdLabel0 = arrayIdLabel0,
                                projectEntry0 = projectEntry0, datasetEntry0 = datasetEntry0,
                                dateEntry0 = dateEntry0))
  for (i in 1:length(arrayIds)){
    aList     <- list()
    indexLabel   <- label(wName = "indexLabel",wValue=i, wEnv=PWEnv2,wWidth=5)
    arrayIdLabel <- label(wName = "arrayIdLabel",wValue=arrayIds[i], wEnv=PWEnv2,wWidth=10)
    projectEntry <- entryBox(wName = "projectEntry", wValue = "", wEnv = PWEnv2,wWidth=20)
    datasetEntry <- entryBox(wName = "datasetEntry", wValue = "", wEnv = PWEnv2,wWidth=20)
    dateEntry    <- entryBox(wName = "dateEntry", wValue = "", wEnv = PWEnv2,wWidth=15)

    aList[paste("indexLabel",i,sep="")]   <- assign(paste("indexLabel",i,sep=""), indexLabel)
    aList[paste("arrayIdLabel",i,sep="")] <- assign(paste("arrayIdLabel",i,sep=""), arrayIdLabel)
    aList[paste("projectEntry",i,sep="")] <- assign(paste("projectEntry",i,sep=""), projectEntry)
    aList[paste("datasetEntry",i,sep="")] <- assign(paste("datasetEntry",i,sep=""), datasetEntry)
    aList[paste("dateEntry",i,sep="")]    <- assign(paste("dateEntry",i,sep=""), dateEntry)


    pWidgets2[paste("row",i,sep="")] <- list(aList)
  }
  aWidget <- widget(wTitle = "Microarray Reporting", pWidgets2,
             preFun=function(){}, postFun=function(){},funs = list(), env = PWEnv2,defaultNames=c("OK","Cancel"))
  resList <- list()
  for (j in i:1){
    kw <-  paste("row",j,sep="")
    resList[wValue(pWidgets(aWidget)[[kw]][[paste("arrayIdLabel",j,sep="")]])] =
        list(list("projectName" = wValue(pWidgets(aWidget)[[kw]][[paste("projectEntry",j,sep="")]]),
             "datasetName" = wValue(pWidgets(aWidget)[[kw]][[paste("datasetEntry",j,sep="")]]),
             "projectDate" = wValue(pWidgets(aWidget)[[kw]][[paste("dateEntry",j,sep="")]])))
  }
  return(resList)
}
#----------------------------------------------------------------------------------------------------------
