#  Get filenames
getReport <- function(pQcType=1,dev="pdf"){

    fileNames  <- dataFileWidget()
    datafile   <- fileNames$datafile    # rows = genes,  columns = samples  from BeadStudio
    qcfile     <- fileNames$qcfile      # rows = samples,columns = metrics
    samplefile <- fileNames$samplefile  # optional file describing each sample

    # Reading in the data
    dataArray <- readFile(datafile)
    qcArray   <- readFile(qcfile)
    arrayType <- getArrayType(dataArray)
    dataArray <- checkMicroarrayData(dataArray)
    qcArray   <- checkMicroarrayData(qcArray)
    qcArray   <- t(qcArray)

    # Get array ID
    arrayIdsData <- getArrayIds(dataArray)
    arrayIdsQc   <- getArrayIds(qcArray)        # arrays id in colnames
    arrayId      <- intersect(arrayIdsData, arrayIdsQc)
    if (length(arrayId)==0) stop("Error: Array ID in qcinfo file does not match array ID in data file")

    # Getting pool data
    poolFilenames   <- poolFileWidget()
    poolDataFile    <- poolFilenames$pDataFile
    poolQcFile      <- poolFilenames$pQcFile
    poolSummaryFile <- poolFilenames$pSummaryFile
    poolType        <- names(which(poolFilenames$pPoolType==T))

    dataPool  <- readFile(poolDataFile)
    if(!("ProbeID"%in%colnames(dataPool))&&colnames(dataPool)[1]=="X") {
      colnames(dataPool)[1]="ProbeID"
      print(paste("GR_Renaming first column of pool data probeID.",dataPool[1,1],"should be a ProbeID"))
    }

    qcPool   <- readFile(poolQcFile)
    if(!("ArrayID"%in%colnames(qcPool))&&colnames(qcPool)[1]=="X") {
      colnames(qcPool)[1]="ArrayID"
      print(paste("GR_Renaming first column of pool qcinfo ArrayID",qcPool[1,1],"should be an ArrayID"))
    }
    
    summaryPool  <- readFile(poolSummaryFile)
     if(!("ArrayID"%in%colnames(summaryPool))&&colnames(summaryPool)[1]=="X") {
      colnames(summaryPool)[1]="ArrayID"
      print(paste("GR_Renaming first column of pool summary ArrayID",summaryPool[1,1],"should be an ArrayID"))
    }

    if (poolType =="HUMAN_REFSEQ8_V2") poolType = "H8v2"
    if (poolType =="HUMAN_REFSEQ8_V1") poolType = "H8v1"
    if (poolType =="MOUSE_REFSEQ8_V1") poolType = "M8v1"
    if (poolType =="HUMAN_WG6_V1") poolType = "H6v1"
    if (poolType =="HUMAN_WG6_V2") poolType = "H6v2"
    
    if (arrayType!=poolType) stop("Pool and array do not match")
    poolName <- basename(poolSummaryFile)
    poolName <- gsub(".txt|_summary", "", poolName, perl=T)

    nSamples  <- length(grep("_[A-H]",colnames(dataArray),perl=T))

    if (samplefile!="") {
          sampleNames <- readFile(samplefile)
          if(nrow(sampleNames)!=nSamples) {
            print(paste("GR_Wrong number of sample names in", basename(samplefile)))
            samplefile=""
          }
    }

    if (samplefile=="")  {
          sampleNames <- cbind(getAlphabetSubset(nSamples,"u"),rep("-",nSamples))
          colnames(sampleNames) <- c("SampleNo","SampleName")
    }

    # Getting meta data
    metas <- metaWidget(arrayId)

    projectName <- metas[[arrayId]][["projectName"]]
    datasetName <- metas[[arrayId]][["datasetName"]]
    projectDate <- metas[[arrayId]][["projectDate"]]
    if (projectDate=="") projectDate="NA"
    #metaData <- c(format(Sys.time(), "%d-%b-%Y"),projectName,datasetName,arrayType, arrayId, nSamples)
    metaData <- c(projectDate,projectName,datasetName,arrayType, arrayId, nSamples, poolName )
    names(metaData)<- c("Date","Project","Dataset","Array_type","Array_id","Nb_samples", "PoolName")

    roa <- reportOnArray(dataArray, dataPool, qcArray, qcPool, summaryPool, metaData, sampleNames, pQcType=pQcType,dev="pdf")
}