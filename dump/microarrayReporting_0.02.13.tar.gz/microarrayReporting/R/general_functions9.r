# This function checks that - data directory in the target file exists
#                           - data files exists in data directory
# abbreviation for output : CTV
checkTargetValue<- function(target){

  # Check that the directory exists
  if(length(dir(target$dirData))==0) stop("CTV_Directory not found or empty")

  # Check that the datafile exists

  for (fileType in c("gene_qcinfo","probe_profile")){
    filename     <- paste(target$arrayId,"_",fileType, ".txt",sep="")
    isfileInDir  <- filename%in%dir(target$dirData)
    if(!isfileInDir) stop(paste("CTV_",filename,".txt not found in ",basename(target$dirData),sep=""))
  }
}
#-------------------------------------------------------------------------------
# Returns the extension of a file
getFileExtension <- function(filename){
  filename  <- basename(filename)
  extension <- strsplit(filename,split="\\.")[[1]][2]
  return(extension)
}
#-------------------------------------------------------------------------------
# For a file containing samples from more than one array, get the array ids
getArrayIds <- function(dat){
    arrayIds <- c()
    idnames  <- colnames(dat)
    if(length(grep("^[0-9]", idnames,perl=T))==0) idnames <- rownames(dat)

    for (i in 1:ncol(dat)){
      arrayId  <- strsplit(idnames[i],split="_")[[1]][1]
      arrayIds <- c(arrayIds, arrayId)
    }
    return(unique(grep("^[0-9]", arrayIds,perl=T,value=T)))
}
#-------------------------------------------------------------------------------
# Using the targetID, identify the array type
getArrayType <- function(dat){
  if (length(grep("TargetID",colnames(dat),perl=T))==0){
    stop("GAT_TargetID column must be present in the data file to determined the type of array")
  }
  targetIds <- dat[,"TargetID"]

  if (length(grep("IGHV",targetIds, perl=T))>0 & length(targetIds)<30000) return("M8v1")# mouse refseq8 v1
  if (length(grep("GI",  targetIds, perl=T))>0 & length(targetIds)<30000) return("H8v1") # human refseq8 v1
  if (length(grep("hmm", targetIds, perl=T))>0 & length(targetIds)>30000) return("H6v1")# human whole genome v1
  if (length(grep("ILMN", targetIds, perl=T,ignore.case = T))>0 & length(targetIds)>40000) return("H6v2")  # human whole genome v2
  if (length(grep("ILMN", targetIds, perl=T,ignore.case = T))>0 & length(targetIds)<30000) return("H8v2") #human refseq8 v2
  else return("unknown")
}
#-------------------------------------------------------------------------------
# Read csv and text file
readFile <- function(filename){

  fileExtension <- getFileExtension(basename(filename))

  if (fileExtension=="csv")  x <- read.csv(filename)
  if (fileExtension=="txt")  x <- read.delim(filename)
  if (!(fileExtension%in%c("csv","txt"))) stop(paste("RF_Extension",fileExtension,"unknown, only reading .csv and .txt",sep=" "))
  return(x)
}
#-------------------------------------------------------------------------------
# Checks and modifies data format for appropriate rownames and numeric type
checkMicroarrayData <- function(dat){

  if (!(is.matrix(dat))) dat <- as.matrix(dat)

  # We only want to keep the numeric values
  if("TargetID" %in% colnames(dat))  {
    rownames(dat) <- dat[,"TargetID"]
    dat <- dat[,!("TargetID"==colnames(dat))]
    print("CMD_Setting TargetID as rownames. Removing TargetID column.")
    }
  if("ArrayID" %in% colnames(dat))  {
    rownames(dat)<- dat[,"ArrayID"]
    dat <- dat[,!("ArrayID"==colnames(dat))]
    print("CMD_Setting ArrayID as rownames. Removing ArrayID column.")
    }
  if("ProbeID" %in% colnames(dat))  {
    rownames(dat)<- dat[,"ProbeID"]
    dat <- dat[,!("ProbeID"==colnames(dat))]
    print("CMD_Setting ProbeID as rownames. Removing ProbeID column.")
    }
  if("SampleID" %in% colnames(dat))  {
    rownames(dat)<- dat[,"SampleID"]
    dat <- dat[,!("SampleID"==colnames(dat))]
    print("CMD_Setting SampleID as rownames. Removing SampleID column.")
    }

  # We keep only average signal
  if (length(grep("AVG_Signal",rownames(dat),ignore.case=T))>0) {
    dat <- dat[grep("AVG_Signal",colnames(dat),perl=T,value=T,ignore.case=T),]
    rownames(dat) <- gsub("AVG_Signal.","",rownames(dat), ignore.case=T)
    print("CMD_Keeping only average signal rows and removing \"AVG_Signal\" from row names")
  }
  if (length(grep("AVG_Signal",colnames(dat),ignore.case=T))>0) {
    dat <- dat[, grep("AVG_Signal",colnames(dat),perl=T,value=T,ignore.case=T)]
    colnames(dat) <- gsub("AVG_Signal|\\.","",colnames(dat),ignore.case=T)
    print("CMD_Keeping only average signal columns and removing \"AVG_Signal\" from column names")
  }
   # We check that we have numeric type as data
  if(!(is.numeric(dat))){
    dat2  <- matrix(as.numeric(dat),ncol=ncol(dat))
    rownames(dat2) <- rownames(dat)
    colnames(dat2) <- colnames(dat)
    dat <- dat2
    print("CMD_Converting to numeric")
    }
  colnames(dat) <- gsub("X","",colnames(dat))
  return(dat)
}
#-------------------------------------------------------------------------------
# Returns the number of value in a dataset over a given cutOff
getNbOverCutoff <- function(dat, cutoff){

    if (missing(cutoff))  stop("GNOC_You need to specify a cutoff")
    nbValues = c()
    for (i in 1:ncol(dat)){
      nbValues <- c(nbValues, length(which(dat[,i]>as.numeric(cutoff[i]))))
    }
    return(nbValues)
}
#--------------------------------------------------------------------------------
# Returns a subset of the alphabet of length n in the specified case
getAlphabetSubset<- function(n,cas){
 if (n > 26) stop("GAS_No more than 26 letters in the alphabet")
 letter  <- c("a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q",
          "r","s","t","u","v","w","x","y","z")
 subletter <- letter[1:n]
 if (tolower(cas)=="u") return(toupper(subletter))
 if (tolower(cas)=="l") return(tolower(subletter))
}


#------------------------------------------------------------------------------
# Returns the given statistic for the dataset
computeStatistic <- function(dat, of, stat){

 if (!(stat %in% c("mad","mean","sd"))) stop("CS_stat must be either mad, mean or sd")
 if (!(of   %in% c("col","row")))       stop("CS_of must be either col or row")

 if (!(is.matrix(dat))) dat <- as.matrix(dat)

 if (of == "col") n <- 2
 if (of == "row") n <- 1


 if (dim(dat)[n]>1) {   # if more than one data entry in the matrix
    if (stat=="mean") datStat <- as.matrix(apply(dat,n,mean))
    if (stat=="mad")  datStat <- as.matrix(apply(dat,n,function(x)mad(x)))
    if (stat=="sd")   datStat <- as.matrix(apply(dat,n,sd))
 }
 else {
    stop("CS_Only one entry.  Did not compute statistics")
  }
  return(datStat)
}
#-------------------------------------------------------------------------------
#----------------------compareToDeviation---------------------------------------
# This function is used to compare the deviation statistic of a distribution
#
flagOutlier <- function(dat,refData,refDeviation){

  nbDeviation <- length(refDeviation)

  if (!(length(refData)%in%dim(dat))) {
    stop ("FO_Reference dataset length != one of data dimension")
  }
  if (!(nbDeviation%in%dim(dat)))     {
    stop ("FO_Deviation (stdev, mad...) length != data dimension")
  }
  if (nbDeviation==dim(dat)[2]) nbDeviation2 <- dim(dat)[1]
  if (nbDeviation==dim(dat)[1]) nbDeviation2 <- dim(dat)[2]

  # Checking the data from the chip and assigning flags when necessary
  for (i in 1:nbDeviation2){

    if (nbDeviation2==dim(dat)[2]) flag   <- ifelse((abs(dat[,i]-refData))> refDeviation,1,0)
    if (nbDeviation2==dim(dat)[1]) flag   <- ifelse((abs(dat[i,]-refData))> refDeviation,1,0)

    if (i==1) {flags <- flag}
    else      {flags <- cbind(flags,flag)}
   }
  flags <- t(flags)
  rownames(flags) <- rownames(dat)
  colnames(flags) <- colnames(dat)
  return(flags)
}
#---------------------------------getSummary------------------------------------
# Returns data summary (min, 1st Qu, Median, 3rd Qu, Max)
getSummary <- function(dat, paramPosition = "rownames"){

   if (!(is.matrix(dat)))  stop("GS_Data is not a matrix")

   paramName <- substr(summary(dat),1,8)[1:6]

   # Get the min, 1st Qu, Median, 3rd Qu, Max
    aSummary <- matrix(as.numeric(matrix(substr(summary(dat),9,20),nrow=6)),nrow=6)
    rownames(aSummary) <- paramName
    colnames(aSummary) <- colnames(dat)

    if (paramPosition=="rownames") return(aSummary)
    if (paramPosition=="colnames") return(t(aSummary))
}
#-------------------------------------------------------------------------------
#----------------------------------modified from gplots package-----------------
textplot2 <- function(object,
                            halign=c("center","left","right"),
                            valign=c("center","top","bottom"),
                            cex, cmar=2, rmar=0.5,
                            show.rownames=TRUE, show.colnames=TRUE,
                            hadj=1,
                            vadj=1,
                            mar= c(1,1,4,1)+0.1,
                            colorMx = NULL,
                            ... )
{

  if(is.vector(object))
    object <- t(as.matrix(object))
  else
    object <- as.matrix(object)

  if (is.null(colorMx)){
     colorMx = matrix("black",nrow=nrow(object),ncol=ncol(object))
  }

  halign=match.arg(halign)
  valign=match.arg(valign)

  opar <- par()[c("mar","xpd","cex")]
  on.exit( par(opar) )
  par(mar=mar, xpd=FALSE )

  # setup plot area
  plot.new()
  plot.window(xlim=c(0,1),ylim=c(0,1), log = "", asp=NA)

  # add 'r-style' row and column labels if not present
  if( is.null(colnames(object) ) )
    colnames(object) <- paste( "[,", 1:ncol(object), "]", sep="" )
  if( is.null(rownames(object)) )
    rownames(object) <- paste( "[", 1:nrow(object), ",]", sep="")


  # extend the matrix to include them
  if( show.rownames )
    {
      object <- cbind( rownames(object), object )
      colorMx = cbind(rep("black",nrow(object)),colorMx)
    }
  if( show.colnames )
    {
      object <- rbind( colnames(object), object )
      colorMx = rbind(rep("black",ncol(object)),colorMx)
    }

  # set the character size
  if( missing(cex) )
    {
      cex <- 1.0
      lastloop <- FALSE
    }
  else
    {
      lastloop <- TRUE
    }

  for (i in 1:20)
    {
      oldcex <- cex

      width  <- sum(
                    apply( object, 2,
                          function(x) max(strwidth(x,cex=cex) ) )
                    ) +
                      strwidth('M', cex=cex) * cmar * ncol(object)

      height <- strheight('M', cex=cex) * nrow(object) * (1 + rmar)

      if(lastloop) break

      cex <- cex / max(width,height)

      if (abs(oldcex - cex) < 0.001)
        {
          lastloop <- TRUE
        }
    }


  # compute the individual row and column heights
  rowheight<-strheight("W",cex=cex) * (1 + rmar)
  colwidth<- apply( object, 2, function(XX) max(strwidth(XX, cex=cex)) ) +
               strwidth("W")*cmar


  width  <- sum(colwidth)
  height <- rowheight*nrow(object)

  # setup x alignment
  if(halign=="left")
    xpos <- 0
  else if(halign=="center")
    xpos <- 0 + (1-width)/2
  else #if(halign=="right")
    xpos <- 0 + (1-width)

  # setup y alignment
  if(valign=="top")
    ypos <- 1
  else if (valign=="center")
    ypos <- 1 - (1-height)/2
  else #if (valign=="bottom")
    ypos <- 0 + height

  x <- xpos
  y <- ypos

  # iterate across elements, plotting them
  xpos<-x
  for(i in 1:ncol(object)) {
    xpos <- xpos + colwidth[i]
    for(j in 1:nrow(object)) {
      ypos<-y-(j-1)*rowheight

      color = colorMx[j,i]
      if( (show.rownames && i==1) || (show.colnames && j==1) )
        text(xpos, ypos, object[j,i], adj=c(hadj,vadj), cex=cex, font=2, col=color,... )

      else
        text(xpos, ypos, object[j,i], adj=c(hadj,vadj), cex=cex, font=1, col=color,... )
    }
  }

  par(opar)
}
#-------------------------------------------------------------------------------
#  Functions------------------writeSectionTitle----modified from R project webpage ------------------------------
#  Graphics function

writeSectionTitle<-function(x,backcolor="black",forecolor="white",cex=2,ypos=0.4){

	plot(x=c(-1,1),y=c(0,1),xlim=c(0,1),ylim=c(0,1),type="n",axes=FALSE,col.axis="white",col.lab="white")
	polygon(x=c(-2,-2,2,2),y=c(-2,2,2,-2),col=backcolor,border=NA)
	par(font=3)
	text(x=0,y=ypos,pos=4,cex=cex,labels=x,col=forecolor)

}
#  Functions------------------plotDensitiesMat-----modified from codelink function-----------------------------------
#  Graphics function

plotDensitiesMat <- function (mat, subset = c(1:dim(mat)[2]), title = NULL,
    legend.cex = 0.95,legend.order =NULL)
{
    val <- mat
    val <- log2(val)
    if(length(subset)==2)  colors <- c("blue","red")
    else  colors <- rainbow(length(subset))

    y.max <- c()
    y.min <- c()
    x.max <- c()
    x.min <- c()
    legend.txt <- c()
    for (n in subset) {
        y.max[n] <- max(density(val[, n], na.rm = TRUE)$y)
        y.min[n] <- min(density(val[, n], na.rm = TRUE)$y)
        x.max[n] <- max(density(val[, n], na.rm = TRUE)$x)
        x.min[n] <- min(density(val[, n], na.rm = TRUE)$x)
    }
    ymax <- max(y.max)
    ymin <- min(y.min)
    xmax <- max(x.max)
    xmin <- min(x.min)

    for (n in 1:ncol(val)){

        if (n == 1){
            par(mgp=c(1,0,0))
            legend.txt <- c(legend.txt, colnames(mat)[n])

            plot(density(val[, n], na.rm = TRUE), col = colors[n],
                main = "",xlab="x",ylab="y",xlim=c(xmin,xmax),ylim=c(ymin,ymax)) }
        else {
          lines(density(val[, n], na.rm = TRUE), col = colors[n])
          legend.txt <- c(legend.txt, colnames(mat)[n]) }
    }
    if (is.null(title))
        title(paste("Density Plot"))
    else title(title)

    legend.ncol <- 1

    if (length(legend.txt)>25){
      legend.cex  <- 0.7
      legend.ncol <- ceiling(length(legend.txt)/25)
    }

    legend(x = "topright", legend = legend.txt, cex = legend.cex,
    fill = colors, inset = 0.01,bty="n", ncol = legend.ncol)
}
#---------------------------------------------------------------------------------
# Generate Heatmap
getHeatMaps <- function(indice, patt, datFit, resultsDecide, sampleAnn, merged,
                      myTitle="", dev="", filename = paste("hm",indice,sep="_")){

  if (length(sample.ann)>3) stop("GHM_Sample annotation must have two column: id, class")
  namefile <- filename

  cols   <- as.vector(sampleAnn[grep(patt,sampleAnn[,2],perl=T),1]) # 2: class, 1:id
  indcol <- grep(patt,sampleAnn[,2],perl=T)

  for (i in 1:3) {
    aTitle <- myTitle
    if (i == 1)   {
      mx <- datFit[abs(resultsDecide[,indice]) == 1,cols]
    }
    if (i == 2)   {
      mx       <- datFit[resultsDecide[,indice] ==  1,cols]
      aTitle   <- paste(aTitle,": up",sep="")
      namefile <- paste(namefile,"_up",sep="")
    }
    if (i == 3)   {
      mx       <- datFit[resultsDecide[,indice] ==  -1,cols]
      aTitle   <- paste(aTitle,": down",sep="")
      namefile <- paste(namefile,"_down",sep="")
    }

    if (dev=="jpg") jpeg(filename = paste(namefile,".jpg",sep=""),quality=100)
    if (dev=="")    x11()

    ilab <- ncol(sample.ann)
    par(cex.main = 0.8)

    if (is.matrix(mx)) {
         heatmap.2(as.matrix(mx) ,main=aTitle, labCol=as.vector(sample.ann[indcol,ilab]),
            labRow=as.vector(merged[rownames(mx),grep("symbol",colnames(merged),ignore.case=T, perl=T)]),
            cexRow=0.95,cexCol=0.95, trace="none",scale="row", cex.main = 0.8, col = greenred(30)) }
    if (dev=="jpg") dev.off()
    }
}
#---------------------------------------------------------------------------
#  write rasmol script to view PCA in 2D
write_rasmol <- function(filename, classes, color){
    toWrite1 <- paste("zap\nload pdb \"", filename, ".pdb\"\nset axes on\n",
    "select off\nconnect\nset ambient 40\nrotate x 180\nselect *\nspacefill 70\nzoom 145\nselect *X\nspacefill off\n", sep="")
    toWrite2 <- ""
    for (i in 1:length(color)) {
    toWrite2 <- paste(toWrite2,
    "select ", classes[i],"\n","color ", color[i],"\n",
      sep="")  }
    toWrite3 <- paste("write \"", filename, ".gif\"\n",sep="")
    write(paste(toWrite1,toWrite2,toWrite3,sep=""), paste(filename, "spt",sep="."))
}

